#------------------------------------------#
# Title: CDInventory.py
# Desc: Main Script
# Change Log: (Who, When, What)
# Maria Dacutanan, 2020-Sept-08, Added 'choose' menu for selecting CD info and adding adding/removing track info
# Maria Dacutanan, 2020-Sept-08, added comments for clarity
# Maria Dacutanan, 2020-Sept-09, remove debug statements

#------------------------------------------#

import ProcessingClasses as PC
import IOClasses as IO


#----------DATA---------#
lstFilenames=['CDInventory.dat','TrackInventory.dat']
lstOfCDObjects = []



#-------Main Body of SCript-------#
#Load CDInventory.dat and TrackInventory.dat
IO.FileIO.load_inventory(lstFilenames,lstOfCDObjects)


#Start main loop
while True:
    # Display Menu to user and get choice
    IO.ScreenIO.print_menu()
    strChoice = IO.ScreenIO.menu_choice()

    #Process menu selection
    #Process exit first
    if strChoice == 'x':
        break
    #procless load inventory
    if strChoice == 'l':
            print('WARNING: If you continue, all unsaved data will be lost and the Inventory re-loaded from file.')
            strYesNo = input('type \'yes\' to continue and reload from file. otherwise reload will be canceled: ')
            if strYesNo.lower() == 'yes':
                print('reloading...')
                IO.FileIO.load_inventory(lstFilenames, lstOfCDObjects)
                IO.ScreenIO.show_inventory(lstOfCDObjects) #show contents of lstOfCDObjects
            else:
                 input('canceling... Inventory data NOT reloaded. Press [ENTER] to continue to the menu.')
                 IO.show_inventory(lstOfCDObjects)

    #process add a CD
    elif strChoice == 'a':
        #Ask user for new ID, CD Title and Artist
        tplCDInfo=IO.ScreenIO.get_newInventory() #function call to prompt user for ID, CD Title and Artist and unpack return values       
        PC.DataProcessor.add_CD(tplCDInfo, lstOfCDObjects)
        print ()
        IO.ScreenIO.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.
    
    #process display current inventory
    elif strChoice == 'i':
        IO.ScreenIO.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.
    elif strChoice == 'c':
        flag=IO.ScreenIO.show_inventory(lstOfCDObjects)
        if (flag): #if inventory is empty, skip submenu
            cd=None
            while True:
                try:
                    cd_idx = input('Select the CD / Album index: ')
                    #retrieve CD object where track info is to be associated
                    cd = PC.DataProcessor.select_cd(lstOfCDObjects, cd_idx)
                    break
                except Exception as e:
                    print (e)
            # TODO add code to handle tracks on an individual CD
            while True:
                IO.ScreenIO.print_CD_menu()
                strChoice=IO.ScreenIO.menu_CD_choice()
                if strChoice=='x':
                    break
                if strChoice=='a':
                    while True:
                        try:
                            # prompt user for for CD track info details
                            tpltrackInfo=IO.ScreenIO.get_track_info()
                            #add track info to list
                            PC.DataProcessor.add_track(tpltrackInfo, cd)
                            break
                        except Exception as e:
                            print (e)
                    #tpltrackInfo=IO.ScreenIO.get_track_info()
                    #PC.DataProcessor.add_track(tpltrackInfo, cd)
                #add track info per CD
                elif strChoice=='d':
                    IO.ScreenIO.show_tracks(cd)
                #remove track info
                elif strChoice=='r':
                    IO.ScreenIO.show_tracks(cd)
                    track_idx=input('Select the track index: ')
                    cd.rem_track(track_idx)
                else:
                    print ('General Error.')
        else:
            continue
            
    elif strChoice == 's':
        #Display current inventory and ask user for confirmation to save
        if (lstOfCDObjects): #check for empty list
             IO.ScreenIO.show_inventory(lstOfCDObjects) #function call to show current inventory
             strYesNo = input('Save this inventory to file? [y/n] ').strip().lower()
             #Process choice
             if strYesNo == 'y':
                IO.FileIO.save_inventory(lstFilenames, lstOfCDObjects)
             else:
                 input('The inventory was NOT saved to file. Press [ENTER] to return to the menu.')
        else:
             print('Nothing to save. Inventory is empty.\n')
        continue  # start loop back at top.
    # 3.7 catch-all should not be possible, as user choice gets vetted in IO, but to be safe:
    else:
        print('General Error')