#------------------------------------------#
# Title: IO Classes
# Desc: Assignnment 09 - A Module for IO Classes
# Change Log: (Who, When, What)
# Maria Dacutanan, 2020-Sept-08, added print_CD_menu and menu_CD_choice methods
# Maria Dacutanan, 2020-Sept-08, added show_tracks, show_CD_info, get_track_info
# Maria Dacutanan, 2020-Sept-09, updated load_inventory to load both CDInventory and TrackInventory
# Maria Dacutanan, 2020-Sept-09, updated save_inventory to save load both CDInventory and TrackInventory
# Maria Dacutanan, 2020-Sept-09, remove debug statements
#------------------------------------------#

import DataClasses as DC
import ProcessingClasses as PC
import pickle

if __name__ == '__main__':
    raise Exception('This file is not meant to run by itself')

class ScreenIO:
    """Handling Input / Output"""

    @staticmethod
    def print_menu():
        """Displays a menu of choices to the user

        Args:
            None.

        Returns:
            None.
        """

        print('Menu\n\n[l] load Inventory from file\n[a] Add CD\n[i] Display Current Inventory')
        print('[c] Choose CD/Album\n[s] Save Inventory to file\n[x] exit\n')

    @staticmethod
    def menu_choice():
        """Gets user input for menu selection

        Args:
            None.

        Returns:
            choice (string): a lower case sting of the users input out of the choices l, a, i, c, s or x

        """
        choice = ' '
        while choice not in ['l', 'a', 'i','c', 's', 'x']:
            choice = input('Which operation wouild you like to perform? [l, a, i, c, s or x]: ').lower().strip()
        print()  # Add extra space for layout
        return choice
    
    @staticmethod
    def print_CD_menu():
        """Displays a sub menu of choices for CD / Album to the user

        Args:
            None.

        Returns:
            None.
        """

        print('CD Sub Menu\n\n[a] Add track\n[d] Display cd / Album details\n[r] Remove track\n[x] exit to Main Menu')
        
    @staticmethod
    def menu_CD_choice():
        """Gets user input for CD sub menu selection

        Args:
            None.

        Returns:
            choice (string): a lower case sting of the users input out of the choices a, d, r or x

        """
        choice = ' '
        while choice not in ['a', 'd', 'r', 'x']:
            choice = input('Which operation would you like to perform? [a, d, r or x]: ').lower().strip()
        print()  # Add extra space for layout
        return choice

    @staticmethod
    def show_inventory(table):
        """Displays current inventory table


        Args:
            table (list of dict): 2D data structure (list of dicts) that holds the data during runtime.

        Returns:
            (boolean).

        """
        if (table):
            print('======= The Current Inventory: =======')
            print('ID\tCD Title (by: Artist)\n')
            for CD in table:
                print(str(CD))
            print('======================================')
            return True
        else:
            print ('Inventory is empty.\n')
            return False
    @staticmethod
    def get_newInventory():
        """Prompts User to provide ID, Title and Arist Name 


        Args:
            None

        Returns:
            strID (string) - ID
            strTitle (string) - Title
            strArtist (string) - Artist

        """
        
        strID = str(input('Enter an ID: ').strip())
        strTitle = input('Enter the CD\'s Title: ').strip()
        strArtist = input('Enter the Artist\'s Name: ').strip()
        return (strID, strTitle, strArtist)

    @staticmethod
    def show_tracks(cd):
        """Displays the Tracks on a CD / Album

        Args:
            cd (CD): CD object.

        Returns:
            None.

        """
        print('====== Current CD / Album: ======')
        print(cd)
        print('=================================')
        print(cd.get_tracks())
        print('=================================')

    @staticmethod
    def get_CD_info():
        """function to request CD information from User to add CD to inventory


        Returns:
            cdId (string): Holds the ID of the CD dataset.
            cdTitle (string): Holds the title of the CD.
            cdArtist (string): Holds the artist of the CD.

        """

        cdId = input('Enter ID: ').strip()
        cdTitle = input('What is the CD\'s title? ').strip()
        cdArtist = input('What is the Artist\'s name? ').strip()
        return cdId, cdTitle, cdArtist

    @staticmethod
    def get_track_info():
        """function to request Track information from User to add Track to CD / Album


        Returns:
            trkId (string): Holds the ID of the Track dataset.
            trkTitle (string): Holds the title of the Track.
            trkLength (string): Holds the length (time) of the Track.

        """
        while True:
            try:
                trkId = input('Enter Position on CD / Album: ').strip()
                trkTitle = input('What is the Track\'s title? ').strip()
                trkLength = input('What is the Track\'s length? ').strip()
                print('id is {}, title is {}, length is {}'.format(trkId,trkTitle,trkLength))
                return (trkId, trkTitle, trkLength)
            except Exception as e:
                print (e)

class FileIO:
    """Processes data to and from file:
        

    methods:
        save_inventory(file_name:list, lst_Inventory): -> None
        load_inventory(file_name): -> (a list of CD objects)

    """

    
    #-----------METHODS-------------#
    @staticmethod
    def load_inventory(file_name:list, table):
        table.clear()
        filename_CD=file_name[0]
        filename_track=file_name[1]
        try:
            with open (filename_CD, 'rb') as pickle_file:
                data = pickle.load(pickle_file)
                table.extend(data)
        except FileNotFoundError as e:
            print('Unable to load inventory from ', filename_CD, '.') #exception handling for file not existing
            print ()
            print (e, e.__doc__, sep='\n')
            print()
        except EOFError as e:
            print(filename_CD, ' is empty.') #exception handling for empty file
            print ()
            print (e, e.__doc__, sep='\n')
            print()
        except pickle.UnpicklingError as e:
            print(filename_CD, ' is corrupted.') #exception handling for unpickling error
            print ()
            print (e, e.__doc__, sep='\n')
            print()
        try:
            with open (filename_track, 'rb') as pickle_file2:
                lst=[]
                data = pickle.load(pickle_file2)
                lst.append(data)
                for line in lst:
                    val1=line.strip().split(',')
                    #retrieve CD object associated with CD tracks
                    cd=PC.DataProcessor.select_cd(table,val1[0])
                    #retrieve cd track info & add it to cd track list
                    track=DC.TrackInfo(val1[1], val1[2], val1[3])
                    cd.add_track(track)
        except FileNotFoundError as e:
            print('Unable to load inventory from ', filename_track, '.') #exception handling for file not existing
            print ()
            print (e, e.__doc__, sep='\n')
            print()
        except EOFError as e:
            print(filename_track, ' is empty.') #exception handling for empty file
            print ()
            print (e, e.__doc__, sep='\n')
            print()
        except pickle.UnpicklingError as e:
            print(filename_track, ' is corrupted.') #exception handling for unpickling error
            print ()
            print (e, e.__doc__, sep='\n')
            print()
        
    @staticmethod
    def save_inventory(file_name:list, table:list) -> None:
        """
        Args:
            file_name(list): list of filenames[CD Inventory, Track Inventory] that hold the data
            table(list): list of CD objects
        
        Returns:
            None
        """
        filename_CD=file_name[0]
        filename_track=file_name[1]
        try:
            #pcikle CDInventory into binar
            with open(filename_CD, 'wb') as pickle_file:
                pickle.dump(table, pickle_file)
            #pickle TrackInventory
            with open(filename_track, 'wb') as pickle_file2:
                for disc in (table):
                    tracks=disc.cd_tracks #get CD tracks
                    disc_id=disc.cd_id
                    for track in tracks:
                        if track is not None:
                            #get cd track and associate with CD id
                            record='{},{}'.format(disc_id, track.get_record())
                            pickle.dump(record,pickle_file2)
                
        except PermissionError as e:
            print('Not enough rights to create/modify ' + file_name + '.') #if unable pickle data due to permission issues
            print ()
            print (e, e.__doc__, sep='\n')
            print ()
        except IOError as e:
            print ('I/O error({0}): {1}'.format(e.errno,e.strerror))#if unable to pickle data due to IO errors such as disk space issues
            print ()
            print (e, e.__doc__, sep='\n')
            print ()
        except pickle.PickleError as e:
            print ('Unable to write data into ' + file_name + '.') #if unable to pickle 2D list, exception handling for pickling errors
            print ()
            print (e, e.__doc__, sep='\n')
            print ()
