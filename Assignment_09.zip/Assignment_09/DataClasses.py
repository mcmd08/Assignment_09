#------------------------------------------#
# Title: Data Classes
# Desc: Assignnment 09 - A Module for Data Classes
# Change Log: (Who, When, What)
# Maria Dacutanan, 2020-Sept-07, added class TrackInfo
# Maria Dacutanan, 2020-Sept-07, added get_record, get_tracks methods, rem_track, sort_track methods
# Maria Dacutanan, 2020-Sept-09, remove debug comments

#------------------------------------------#

if __name__ == '__main__':
    raise Exception('This file is not meant to run by itself')

class TrackInfo():
    """Stores Data about a Single Track:
        
        properties:
            position(numeric): Track Position on CD/Album
            Tracktitle(string):track title
            Tracklen(string): Track length
        
        methods:
            get_record()
        """
    #------------CONSTRUCTOR--------------#
    def __init__(self,pos,title,trcklen):
        #--------Attributes---------#
        self.__position=pos
        self.__Tracktitle=title
        self.__Tracklen=trcklen
    
    @property
    def position(self):
        return (self.__position)
    
    @position.setter
    def position (self,val1):
        if not val1.isnumeric():
            raise Exception('Position must be numeric.')
        else:
            self.__position=val1
    
    @property
    def Tracktitle(self):
        return (self.__Tracktitle)
   
    @Tracktitle.setter
    def Tracktitle(self,val1):
        if (val1):
            self.__Tracktitle=val1
        else:
            raise Exception('Track Title must not be empty.')
        
    @property
    def Tracklen(self):
        return (self.__Tracklen)
    
    @Tracklen.setter
    def Tracklen(self, val1):
        if(val1):
            self.__Tracklen=val1
        else:
            raise Exception ('Track Length must not be empty.')

    #------------METHODS--------------#

    def __str__(self):
        """Returns Track details as formatted string"""

        return '{:>2}\t{} ({})'.format(self.position, self.Tracktitle, self.Tracklen)
        #return f"ID: {self.cd_id},{self.cd_title},{self.cd_artist}"
    
    def __repr__(self):
        #return f"ID {self.cd_id} {self.cd_title} by:{self.cd_artist}"
        return '{:>2}\t{} ({})'.format(self.position, self.Tracktitle, self.Tracklen)
    
    def get_record(self):
        """Returns Track Record formatted for saving to file"""
        return '{},{},{}\n'.format(self.position, self.Tracktitle, self.Tracklen)

class CD:
    """Stores data about a CD:

    properties:
        cd_id: (int) with CD ID
        cd_title: (string) with the title of the CD/ Album
        cd_artist: (string) with the artist of the CD/ Album
        cd_tracks: (list) trackinfo objects of the CD/ Album
    methods:
        get_record: (string) returns CD record formatted for saving to file
        add_track(track): -> None
        rem_track(int): -> None
        get_tracks(): -> string
        get_long_rec(): -> string
        

    """
    def __init__(self,id,title,artist): #initialize default attributes
        self.__cd_id=id
        self.__cd_title=title
        self.__cd_artist=artist
        self.__cd_tracks=[]
    
    #Add property to cd_id to allow setting value for attribute cd_id
    @property
    def cd_id(self):
        return (self.__cd_id)
    
    @cd_id.setter
    def cd_id (self,val1):
        #Check for numeric entry; if not numberic, raise an exception
        if not val1.isnumeric():
            raise Exception('ID cannot be null and must be numeric.\n')
        else:
            self.__cd_id=val1
    
    #Add property to allow setting the value for attribute cd_title
    @property
    def cd_title(self):
        return (self.__cd_title)
   
    @cd_title.setter
    def cd_title(self,val1):
        #Check for null cd_title; if empty, raise an exception
        if (val1):
            self.__cd_title=val1
        else:
            print()
            raise Exception('CD Title must not be empty.\n')

    #Add property to allow setting value for attribute cd_artist
    @property
    def cd_artist(self):
        return (self.__cd_artist)
   
    @cd_artist.setter
    def cd_artist(self,val1):
        #Check for null cd_artist; if empty, raise an exception
        if (val1):
            self.__cd_artist=val1
        else:
            raise Exception('CD Artist must not be empty.\n')
    
    #Add property to allow for retrieval of attribute cd_tracks
    @property
    def cd_tracks(self):
        return self.__cd_tracks
    

    #-----------METHODS------------#
    
    def __str__(self):
        """Returns CD details as formatted string"""
        return '{:>2}\t{} (by: {})'.format(self.cd_id, self.cd_title, self.cd_artist)
    
    def __repr__(self):
        return '{:>2}\t{} (by: {})'.format(self.cd_id, self.cd_title, self.cd_artist)
    
    def get_record(self):
        """Returns CD Record formatted for saving to file"""
        return '{},{},{}\n'.format(self.cd_id, self.cd_title, self.cd_artist)
    
    def add_track(self, track: TrackInfo) -> None:
        """Adds a track to the CD / Album


        Args:
            track (Track): Track object to be added to CD / Album.

        Returns:
            None.

        """
        # TODO append track
        self.__cd_tracks.append(track)
        self.__sort_tracks()
        # TODO sort tracks

    def rem_track(self, track_id: int) -> None:
        """Removes the track identified by track_id from Album


        Args:
            track_id (int): ID of track to be removed.

        Returns:
            None.

        """
        # TODO remove track
        while True:
            try:
                del self.__cd_tracks[int(track_id) - 1]
                self.__sort_tracks()
            except:
                print ('Position is not valid.\n')
                break
        # TODO sort tracks
        

    def __sort_tracks(self):
        """Sorts the tracks using Track.position. Fills blanks with None"""
        n = len(self.__cd_tracks)
        for track in self.__cd_tracks:
            if (track is not None) and (n < int(track.position)):
                n = track.position
        tmp_tracks = [None] * int(n)
        for track in self.__cd_tracks:
            if track is not None:
                tmp_tracks[int(track.position) - 1] = track
        self.__cd_tracks = tmp_tracks

    def get_tracks(self) -> str:
        """Returns a string list of the tracks saved for the Album

        Raises:
            Exception: If no tracks are saved with album.

        Returns:
            result (string):formatted string of tracks.

        """
        self.__sort_tracks()
        if len(self.__cd_tracks) < 1:
            raise Exception('No tracks saved for this Album')
        result = ''
        for track in self.__cd_tracks:
            if track is None:
                result += 'No Information for this track\n'
            else:
                result += str(track) + '\n'
        return result

    def get_long_rec(self) -> str:
        """gets a formatted long record of the Album: Album information plus track details


        Returns:
            result (string): Formatted information about ablum and its tracks.

        """
        result = self.get_record() + '\n'
        result += self.get_tracks() + '\n'
        return result




