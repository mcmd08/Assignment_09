#------------------------------------------#
# Title: Processing Classes
# Desc: A Module for processing Classes
# Change Log: (Who, When, What)
# Maria Dacutanan, 2020-Sept-08, added add_CD and add_track methods
# Maria Dacutanan, 2020-Sept-09, cleaned up debug statements
#------------------------------------------#

if __name__ == '__main__':
    raise Exception('This file is not meant to ran by itself')

import DataClasses as DC

class DataProcessor:
    """Processing the data in the application"""
    
    @staticmethod
    def add_CD(CDInfo, table):
        """function to add CD info in CDinfo to the inventory table.


        Args:
            CDInfo (tuple): Holds information (ID, CD Title, CD Artist) to be added to inventory.
            table (list of dict): 2D data structure (list of dicts) that holds the data during runtime.

        Returns:
            None.

        """

        try:
            #check CD object attributes for validity
            cd_id,title,artist=CDInfo
            objCD=DC.CD(artist,title,artist)
            objCD.cd_id=cd_id
            objCD.cd_title=title
            objCD.cd_artist=artist
        except Exception as e:
            print(e)
        table.append(objCD)

    @staticmethod
    def select_cd(table: list, cd_idx: int) -> DC.CD:
        """selects a CD object out of table that has the ID cd_idx

        Args:
            table (list): Inventory list of CD objects.
            cd_idx (int): id of CD object to return

        Raises:
            Exception: If id is not in list.

        Returns:
            row (DC.CD): CD object that matches cd_idx

        """
        # TODO add code as required
        if not cd_idx.isnumeric():
            raise Exception('Position must be numeric.')
            return None
        else:
            for row in (table):
                if row.cd_id==cd_idx:
                    return row
    
        raise Exception('This CD/Album index does not exist.')
                

    @staticmethod
    def add_track(track_info: tuple, cd: DC.CD) -> None:
        """adds a Track object with attributes in track_info to cd


        Args:
            track_info (tuple): Tuple containing track info (position, title, Length).
            cd (DC.CD): cd object the tarck gets added to.

        Raises:
            Exception: DESCraised in case position is not an integer.

        Returns:
            None: DESCRIPTION.

        """

        # TODO add code as required
        track_pos, track_title, track_len=track_info
        
        if not track_pos.isnumeric():
            raise Exception('Position must be numeric.')
        else:
            track=DC.TrackInfo(track_pos, track_title, track_len)
            print ('track is ', track)
            cd.add_track(track)
    
            
    



